<?php
include '../../db/connetion.php';

class phieuluong extends Database{
    function getWorkingDays($month, $year) {
        // Tổng số ngày trong tháng
        $totalDays = cal_days_in_month(CAL_GREGORIAN, $month, $year);
    
        $workingDays = 0; // Biến đếm số ngày làm việc
    
        // Lặp qua từng ngày trong tháng
        for ($day = 1; $day <= $totalDays; $day++) {
            // Lấy thông tin thứ của ngày
            $dayOfWeek = date('N', strtotime("$year-$month-$day"));
    
            // Chỉ tính ngày làm việc (thứ 2 đến thứ 6)
            if ($dayOfWeek >= 1 && $dayOfWeek <= 5) {
                $workingDays++;
            }
        }
    
        return $workingDays;
    }
public function loadphieuluong( $user_id, $month, $year) {
    // Sửa câu truy vấn để lấy dữ liệu dựa trên ID của người dùng
    $sql = 'SELECT u.manv, u.full_name, u.email, r.role_name, d.department_name, d.salary_coefficient, r.rank_salary, 
            SUM(s.work_time) as sum_work_time, d.maphong,COUNT(s.work_time) AS count_work_time
            FROM users u 
            INNER JOIN user_info ui ON u.info_id = ui.id
            INNER JOIN roles r ON u.role_id = r.id
            INNER JOIN departments d ON u.department_id = d.id
            INNER JOIN attendance a ON u.id = a.user_id
            INNER JOIN shifts s ON s.id = a.shift_id

            WHERE u.id = :user_id
            AND MONTH(a.clock_in_time) = :month
            AND YEAR(a.clock_in_time) = :year;'; 
    
    // Kết nối tới cơ sở dữ liệu
    $link = $this->getConnection();
    if ($link) {
       
        $stmt = $link->prepare($sql);
        
        // Gán giá trị cho placeholder :id
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':month', $month, PDO::PARAM_INT);
        $stmt->bindParam(':year', $year, PDO::PARAM_INT);
       
        // Thực thi truy vấn
        $stmt->execute();

        // Lấy kết quả
        $ketqua = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $i = count($ketqua);

        // Kiểm tra nếu có kết quả
        if ($i > 0) {
           
            $user = $ketqua[0];
            $luongchinh = $user['rank_salary'] * $user['salary_coefficient'];
            $ngaycongtieuchuan = $this->getWorkingDays($month, $year);
            $luongngaycong = round(($luongchinh / $ngaycongtieuchuan) * $user['sum_work_time'],3);
            $luongkpi=$luongngaycong;
            echo '
                    
                            <tr>
                            <td>1</td>
                            <td>Mã nhân viên</td>
                            <td>'.$user['manv'].'</td>
                            <td></td>
                            </tr>
                            <tr>
                            <td>2</td>
                            <td>Họ và tên nhân viên</td>
                            <td>'.$user['full_name'].'</td>
                            <td></td>
                            </tr>
                            <tr>
                            <td>3</td>
                            <td>Email</td>
                            <td>'.$user['email'].'</td>
                            <td></td>
                            </tr>
                            <tr>
                            <td>4</td>
                            <td>Chức danh công việc</td>
                            <td>'.$user['role_name'].' '.$user['maphong'].'</td>
                            <td></td>
                            </tr>
                            <tr>
                            <td>5</td>
                            <td>Phòng</td>
                            <td>'.$user['department_name'].'</td>
                            <td></td>
                            </tr>
                            <tr>
                            <td>6</td>
                            <td>Lương chính thức</td>
                            <td>'.number_format($luongchinh, 3, ',', '.').'</td>
                            <td></td>
                            </tr>
                            <tr>
                            <td>7</td>
                            <td>Ngày công tiêu chuẩn</td>
                            <td>'.$ngaycongtieuchuan.'</td>
                            <td></td>
                            </tr>
                            <tr>
                            <td>8</td>
                            <td>Ngày công thực tế</td>
                            <td>'.$user['sum_work_time'].'</td>
                            <td></td>
                            </tr>
                            <tr class="highlight">
                            <td>9</td>
                            <td>Lương theo ngày công LVTT</td>
                            <td>'.number_format($luongngaycong, 3,',', '.').'</td>
                            <td>[1]</td>
                            </tr>
                            
                            ';
                            $this->loadphucap($user_id, $month, $year, $luongkpi,$user['count_work_time']);
                            
        } else {
            // Log the parameters for debugging
            error_log("No data found for user_id: $user_id, month: $month, year: $year");
            echo 'Không có dữ liệu';
        }
    } else {
        echo 'Không thể kết nối đến cơ sở dữ liệu';
    }
}
public function loadphucap( $user_id, $month, $year,$luongkpi,$ngaycongthucte) {
    $sql = 'SELECT  tr.id, tr.user_id, tr.category_id, tr.amount, tr.transaction_date, ca.name
            FROM   
            transactions tr
            INNER JOIN categories ca ON ca.id = tr.category_id 
                        
            WHERE tr.user_id = :user_id
            AND MONTH(tr.transaction_date) = :month
            AND YEAR(tr.transaction_date) = :year;';
            $link = $this->getConnection();
    
    if ($link) {
        $stmt = $link->prepare($sql);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':month', $month, PDO::PARAM_INT);
        $stmt->bindParam(':year', $year, PDO::PARAM_INT);
        $stmt->execute();

        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (count($result) > 0) {
            $dem=10;
            $pc_hh=0;
            foreach ($result as $row) {
                if($row['category_id']==1 || $row['category_id']==2 ||  $row['category_id']==4){
                     echo '<tr>
                            <td>'.$dem.'</td>
                            <td>'.$row['name'].'</td>
                            <td>'.number_format($row['amount'], 3, ',', '.').'</td>
                            <td></td>
                        </tr>
                           ';
                           $pc_hh+=$row['amount'];
                } 
                elseif($row['category_id']==3){
                    $tienguixe=round($ngaycongthucte*$row['amount'],3);
                    echo '<tr>
                            <td>'.$dem.'</td>
                            <td>'.$row['name'].'</td>
                            <td>'.number_format($tienguixe, 3, ',', '.').'</td>
                            <td></td>
                        </tr>
                           ';
                           $pc_hh+=$tienguixe;
                }
                
                $dem++;
               
            }
            $dem++;
            echo '<tr class="highlight">
                    <td>'.$dem.'</td>
                    <td>Tổng Phụ cấp + hoa hồng</td>
                    <td>'.number_format($pc_hh, 3, ',', '.').'</td>
                    <td>[2]</td>
                </tr>
                ';
                $dem++;
                $sum_amount=$pc_hh+$luongkpi;
            echo '<tr class="highlight">
                    <td>'.$dem.'</td>
                    <td>Tổng thu nhập</td>
                    <td>'.number_format($sum_amount, 3, ',', '.').'</td>
                    <td>[3] =[1]+[2]</td>
                </tr>
                ';
                $sumtru=0;
            foreach ($result as $row) {
                if($row['category_id']==5 || $row['category_id']==6 || $row['category_id']==7 || $row['category_id']==8){
                     echo '<tr>
                            <td>'.$dem.'</td>
                            <td>'.$row['name'].'</td>
                            <td>'.number_format($row['amount'], 3, ',', '.').'</td>
                            <td></td>
                        </tr>
                           ';
                           $sumtru+=$row['amount'];
                } 
                
               
                $dem++;
               
            }
            echo '<tr class="highlight">
                            <td>'.$dem.'</td>
                            <td>Tổng các khoản trừ</td>
                            <td>'.number_format($sumtru, 3, ',', '.').'</td>
                            <td>[4]</td>
                        </tr>
                           ';
            $luong=$sum_amount-$sumtru;
            echo '<tr class="highlight">
                    <td>'.$dem.'</td>
                    <td>Tổng thu nhập</td>
                    <td>'.number_format($luong, 3, ',', '.').'</td>
                    <td>[5] =[4]+[3]</td>
                </tr>
                ';

        } else {
            echo 'No data available';
        }
    } else {
        echo 'Cannot connect to the database';
    }
}



}
?>